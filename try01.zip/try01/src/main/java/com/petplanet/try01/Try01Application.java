package com.petplanet.try01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Try01Application {

	public static void main(String[] args) {
		SpringApplication.run(Try01Application.class, args);
	}

}
